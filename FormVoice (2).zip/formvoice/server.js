/* ============================================================
   FormVoice — server.js
   Accessible voice form-filler for blind and low-vision users.

   What this server does:
   1. Serves the web app (the public/ folder).
   2. /api/analyze  — takes a photo of a form, asks Claude to read
                      every field, returns them as a list.
   3. /api/share    — saves a completed form and returns a link.
   4. /view/:id     — shows a completed form at that link.
   5. /api/email    — (optional) emails a completed form as text.

   You only NEED an Anthropic API key for this to work.
   Email is optional.
   ============================================================ */

const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Allow large bodies because photos are sent as text (base64).
app.use(express.json({ limit: '25mb' }));

// Serve the web app (everything in /public).
app.use(express.static(path.join(__dirname, 'public')));

/* ------------------------------------------------------------
   1. ANALYZE A FORM PHOTO
   The app sends a photo. We ask Claude to find every field
   and send back a clean list the app can read aloud.
------------------------------------------------------------ */
app.post('/api/analyze', async (req, res) => {
  try {
    const { imageBase64, mediaType } = req.body || {};

    if (!imageBase64) {
      return res.status(400).json({ error: 'No image was received.' });
    }
    if (!process.env.ANTHROPIC_API_KEY) {
      return res.status(500).json({
        error: 'The server has no Anthropic API key set. Add ANTHROPIC_API_KEY in your hosting settings.'
      });
    }

    const instructions =
      'You are looking at a photo or screenshot of a paper or web form. ' +
      'List every field a person would need to fill in. ' +
      'Respond with ONLY a JSON array and nothing else — no explanation, no markdown. ' +
      'Each item must look like: ' +
      '{"label": "the field name as a person would say it", ' +
      '"type": "text | date | phone | email | number | select | checkbox | textarea", ' +
      '"required": true or false, ' +
      '"options": ["only for select or checkbox fields, otherwise leave out"]}. ' +
      'Keep labels short and natural, the way you would read them aloud. ' +
      'If the form has sections, keep the fields in reading order.';

    const apiResp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: process.env.CLAUDE_MODEL || 'claude-sonnet-4-6',
        max_tokens: 2000,
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'image',
                source: {
                  type: 'base64',
                  media_type: mediaType || 'image/jpeg',
                  data: imageBase64
                }
              },
              { type: 'text', text: instructions }
            ]
          }
        ]
      })
    });

    const data = await apiResp.json();

    if (data.error) {
      console.error('Claude API error:', data.error);
      return res.status(502).json({
        error: 'The form reader had trouble. ' + (data.error.message || 'Please try another photo.')
      });
    }

    // Pull the text out of Claude's reply and parse the JSON list.
    const text = (data.content || [])
      .map((block) => (block.type === 'text' ? block.text : ''))
      .join('')
      .trim();

    const cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim();

    let fields;
    try {
      fields = JSON.parse(cleaned);
    } catch (e) {
      // If parsing fails, try to grab the array out of the middle of the text.
      const start = cleaned.indexOf('[');
      const end = cleaned.lastIndexOf(']');
      if (start !== -1 && end !== -1) {
        fields = JSON.parse(cleaned.slice(start, end + 1));
      } else {
        throw e;
      }
    }

    if (!Array.isArray(fields) || fields.length === 0) {
      return res.status(422).json({
        error: 'No fields were found on that image. Try a clearer, closer photo.'
      });
    }

    res.json({ fields });
  } catch (err) {
    console.error('Analyze failed:', err);
    res.status(500).json({
      error: 'Something went wrong reading the form. Please try again.'
    });
  }
});

/* ------------------------------------------------------------
   2. SHARE A COMPLETED FORM
   Saves the answers in memory and returns a short link.
   NOTE: on a free host that sleeps, saved forms may clear when
   the app restarts. That is fine for short-term sharing.
------------------------------------------------------------ */
const savedForms = new Map();

function makeId() {
  return Math.random().toString(36).slice(2, 8) + Math.random().toString(36).slice(2, 6);
}

app.post('/api/share', (req, res) => {
  const { title, answers } = req.body || {};
  if (!Array.isArray(answers)) {
    return res.status(400).json({ error: 'Nothing to save.' });
  }
  const id = makeId();
  savedForms.set(id, {
    title: title || 'Completed form',
    answers,
    savedAt: new Date().toISOString()
  });
  res.json({ id });
});

/* ------------------------------------------------------------
   3. VIEW A SHARED FORM
   Anyone with the link can open the completed form.
------------------------------------------------------------ */
app.get('/view/:id', (req, res) => {
  const form = savedForms.get(req.params.id);
  if (!form) {
    return res
      .status(404)
      .send('<h1 style="font-family:sans-serif;padding:40px">This form link was not found or has expired.</h1>');
  }

  const rows = form.answers
    .map(
      (a) =>
        `<tr><th style="text-align:left;padding:14px 16px;border-bottom:1px solid #ddd;font-size:20px;width:40%">${escapeHtml(
          a.label
        )}</th><td style="padding:14px 16px;border-bottom:1px solid #ddd;font-size:20px">${escapeHtml(
          a.value || '(left blank)'
        )}</td></tr>`
    )
    .join('');

  res.send(`<!doctype html><html lang="en"><head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(form.title)}</title></head>
  <body style="font-family:'Atkinson Hyperlegible',Arial,sans-serif;max-width:760px;margin:0 auto;padding:30px;color:#10243e">
    <h1 style="font-size:30px">${escapeHtml(form.title)}</h1>
    <p style="font-size:16px;color:#555">Completed ${new Date(form.savedAt).toLocaleString()}</p>
    <table style="width:100%;border-collapse:collapse;margin-top:20px">${rows}</table>
  </body></html>`);
});

/* ------------------------------------------------------------
   4. EMAIL A COMPLETED FORM (optional)
   Only works if you set the Gmail settings in your host.
------------------------------------------------------------ */
app.post('/api/email', async (req, res) => {
  try {
    const { to, title, answers } = req.body || {};
    if (!to || !Array.isArray(answers)) {
      return res.status(400).json({ error: 'Missing an email address or answers.' });
    }
    if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
      return res.status(400).json({
        error: 'Email is not set up yet. Add GMAIL_USER and GMAIL_APP_PASSWORD in your host settings.'
      });
    }

    const nodemailer = require('nodemailer');
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD
      }
    });

    const lines = answers
      .map((a) => `${a.label}: ${a.value || '(left blank)'}`)
      .join('\n');

    await transporter.sendMail({
      from: process.env.GMAIL_USER,
      to,
      subject: title || 'Completed form from FormVoice',
      text: `${title || 'Completed form'}\n\n${lines}\n\nSent with FormVoice.`
    });

    res.json({ ok: true });
  } catch (err) {
    console.error('Email failed:', err);
    res.status(500).json({ error: 'The email could not be sent. Check your Gmail settings.' });
  }
});

/* Small helper so shared pages can't be broken by odd characters. */
function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

app.listen(PORT, () => {
  console.log(`FormVoice is running on port ${PORT}`);
});
