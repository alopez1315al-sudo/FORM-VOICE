# FormVoice — Setup Guide

FormVoice lets someone take a photo of any form, hear each field read
aloud, answer by voice, and then download, link, or email the finished
form. This guide gets it live on the internet so the microphone works.

You do NOT need to know how to code. Follow the steps in order.

There are two things you must get for it to work:

1. An **Anthropic API key** — this is what reads the form from a photo.
2. A free **Render** account — this puts the app on the internet with a
   secure web address (the microphone only works on a secure address).

Everything below walks through both.

---

## PART 1 — Get your Anthropic API key (about 5 minutes)

1. Go to **https://console.anthropic.com**
2. Sign up or log in.
3. On the left, find **API Keys**. Click **Create Key**.
4. Give it a name like "FormVoice" and click create.
5. **Copy the key** — it starts with `sk-ant-`. Save it somewhere safe.
   You will paste it into Render in Part 3.

Note: using the key costs a small amount per form read (usually a
fraction of a cent). You add a payment method under **Billing**. You can
set a low monthly limit so there are no surprises.

---

## PART 2 — Put the app on Render (about 10 minutes)

Render is a free hosting service. The easiest path is GitHub, but here is
the simplest no-GitHub method.

### Option A — Drag and drop with GitHub (recommended, stays updated)

1. Go to **https://github.com** and make a free account.
2. Click **New repository**, name it `formvoice`, click **Create**.
3. Click **uploading an existing file**, then drag in ALL the files from
   this folder (server.js, package.json, the public folder, etc.).
4. Click **Commit changes**.
5. Go to **https://render.com** and sign up (you can use your GitHub login).
6. Click **New +** then **Web Service**.
7. Connect your `formvoice` repository.
8. Render fills in most settings. Confirm:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
9. Before clicking create, scroll to **Environment Variables** and do Part 3.

### Option B — No GitHub

Render's free tier works best with GitHub, but you can also use Render's
"Public Git repository" field if someone hosts the code for you. If that
feels like too much, ask a sighted helper to do Option A once — after that
you never touch it again.

---

## PART 3 — Add your key (the important step)

In Render, on the **Environment** tab (or the Environment Variables
section during setup), add this:

| Key                 | Value                          |
|---------------------|--------------------------------|
| `ANTHROPIC_API_KEY` | your `sk-ant-...` key from Part 1 |

That is the only one you NEED.

Then click **Create Web Service** (or **Save Changes**). Render builds the
app and starts it. Wait about a minute.

---

## PART 4 — Your live app

Render gives you a web address like:

    https://formvoice-xxxx.onrender.com

Open it in **Chrome** or **Safari** on any phone or computer.
When it asks **"Allow microphone?"**, tap **Allow**.

That's it. Tap "Try the demo" first to hear how it works, then take a
photo of a real form.

---

## OPTIONAL — Turn on the Email button

If you want the "Email this form" button to work, you need a Gmail App
Password (this is NOT your normal Gmail password):

1. Go to **https://myaccount.google.com/apppasswords**
   (you must have 2-Step Verification turned on first).
2. Create an app password. Google shows you 16 letters.
3. In Render's **Environment** tab, add two more:
   - `GMAIL_USER` = your gmail address
   - `GMAIL_APP_PASSWORD` = the 16 letters
4. Save. Render restarts and the email button now works.

If you skip this, everything else still works — people can use Download
PDF and Create a link instead.

---

## A note about the free tier

Render's free service "goes to sleep" after a while with no use. The first
visit after it sleeps takes about 30 seconds to wake up — that's normal.
If you want it always-on and instant, Render has a low-cost paid tier.

Also on the free tier, shareable links may clear when the app restarts, so
treat them as short-term. Download PDF is the most permanent option.

---

## If something doesn't work

- **"The server has no Anthropic API key set"** → the key in Part 3 is
  missing or misspelled. Check it in Render's Environment tab.
- **Microphone won't turn on** → make sure the address starts with
  `https://`, and use Chrome or Safari. Firefox is unreliable for voice.
- **"No fields were found"** → take a clearer, closer, well-lit photo.
- **App is slow on first load** → it was asleep; give it 30 seconds.

You built something genuinely useful here. Once it's live, it just works.
